"use client";

import React, { useEffect, useState } from "react";

// Function to import CSS styles
export const injectStylesheet = () => {
  // If style is already loaded, don't load it again
  if (document.getElementById("easy-adminpanel-styles")) {
    return;
  }

  // We define CSS code directly here
  const cssContent = `/* Easy AdminPanel Styles */
  :root {
    --admin-dark-blue-900: #0D1F36;
    --admin-dark-blue-800: #12263F;
    --admin-dark-blue-700: #183054;
    --admin-dark-blue-600: #1D3A6A;
    --admin-dark-blue-500: #2E4780;
    --admin-blue-500: #3378FF;
    --admin-blue-400: #4A8CFF;
    --admin-blue-300: #75AAFF;
    --admin-gray-100: #F7F9FC;
    --admin-gray-200: #EAF0F7;
    --admin-gray-300: #D9E2EC;
    --admin-gray-400: #B3C2D1;
    --admin-gray-500: #8696A7;
  }
  
  /* Basic Container Styles */
  .admin-container {
    max-width: 95%;
    margin-left: auto;
    margin-right: auto;
    padding-left: 0.5rem;
    padding-right: 0.5rem;
  }
  
  .admin-card {
    background-color: var(--admin-dark-blue-800);
    border-radius: 0.5rem;
    box-shadow: 0 2px 5px 0 rgba(0,0,0,0.05);
    transition: box-shadow 0.2s;
    padding: 1.5rem;
  }
  
  .admin-card:hover {
    box-shadow: 0 5px 15px 0 rgba(0,0,0,0.1);
  }
  
  /* Sidebar Styles */
  .admin-sidebar {
    position: fixed;
    left: 0;
    top: 0;
    height: 100%;
    width: 16rem;
    background-color: var(--admin-dark-blue-800);
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    z-index: 40;
  }
  
  .admin-sidebar-header {
    padding: 1.5rem;
    border-bottom: 1px solid var(--admin-dark-blue-700);
  }
  
  .admin-sidebar-logo {
    display: flex;
    align-items: center;
    font-size: 1.25rem;
    font-weight: 700;
    color: white;
  }
  
  .admin-sidebar-logo svg {
    margin-right: 0.75rem;
    color: var(--admin-blue-400);
  }
  
  .admin-sidebar-content {
    padding: 1rem;
  }
  
  .admin-sidebar-link {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    color: var(--admin-gray-400);
    border-radius: 0.375rem;
    transition: all 0.2s;
    margin-bottom: 0.5rem;
  }
  
  .admin-sidebar-link:hover {
    color: white;
    background-color: var(--admin-dark-blue-700);
  }
  
  .admin-sidebar-link.active {
    color: white;
    background-color: var(--admin-dark-blue-600);
  }
  
  .admin-sidebar-link svg {
    margin-right: 0.75rem;
  }
  
  /* Main Content Styles */
  .admin-main-content {
    margin-left: 16rem;
    padding: 1.5rem;
    min-height: 100vh;
  }
  
  /* Typography Styles */
  .admin-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: white;
  }
  
  .admin-subtitle {
    font-size: 1.25rem;
    font-weight: 600;
    color: var(--admin-gray-200);
  }
  
  /* Button Styles */
  .admin-button-primary {
    background-color: var(--admin-blue-500);
    color: white;
    font-weight: 500;
    padding: 0.5rem 1rem;
    border-radius: 0.375rem;
    transition: background-color 0.2s;
    display: inline-flex;
    align-items: center;
  }
  
  .admin-button-primary:hover {
    background-color: var(--admin-blue-400);
  }
  
  .admin-button-primary svg {
    margin-right: 0.5rem;
  }
  
  .admin-button-secondary {
    background-color: var(--admin-dark-blue-700);
    color: white;
    font-weight: 500;
    padding: 0.5rem 1rem;
    border-radius: 0.375rem;
    transition: background-color 0.2s;
    display: inline-flex;
    align-items: center;
  }
  
  .admin-button-secondary:hover {
    background-color: var(--admin-dark-blue-600);
  }
  
  .admin-button-secondary svg {
    margin-right: 0.5rem;
  }
  
  /* Table Styles */
  .admin-table {
    width: 100%;
    text-align: left;
  }
  
  .admin-table th {
    padding: 0.75rem 1rem;
    color: var(--admin-gray-400);
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.025em;
    border-bottom: 1px solid var(--admin-dark-blue-700);
  }
  
  .admin-table td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid var(--admin-dark-blue-700);
  }
  
  .admin-table tr:hover {
    background-color: var(--admin-dark-blue-700);
  }
  
  /* Form Styles */
  .admin-input {
    background-color: var(--admin-dark-blue-700);
    border: 1px solid var(--admin-dark-blue-600);
    color: white;
    border-radius: 0.375rem;
    padding: 0.5rem 1rem;
  }
  
  .admin-input:focus {
    outline: none;
    box-shadow: 0 0 0 2px var(--admin-blue-500);
  }
  
  .admin-search {
    background-color: var(--admin-dark-blue-700);
    border: 1px solid var(--admin-dark-blue-600);
    color: white;
    border-radius: 0.375rem;
    padding: 0.5rem 2.5rem 0.5rem 1rem;
    width: 100%;
  }
  
  .admin-search:focus {
    outline: none;
    box-shadow: 0 0 0 2px var(--admin-blue-500);
  }
  
  /* Toggle Styles */
  .admin-toggle {
    position: relative;
    display: inline-flex;
    height: 1.5rem;
    width: 2.75rem;
    align-items: center;
    border-radius: 9999px;
    background-color: var(--admin-dark-blue-700);
  }
  
  .admin-toggle-active {
    background-color: var(--admin-blue-500);
  }
  
  .admin-toggle-circle {
    display: inline-block;
    height: 1rem;
    width: 1rem;
    transform: translateX(0.25rem);
    border-radius: 9999px;
    background-color: white;
    transition: transform 0.2s;
  }
  
  .admin-toggle-active .admin-toggle-circle {
    transform: translateX(1.25rem);
  }
  
  /* Status Indicator Styles */
  .admin-status-indicator {
    display: inline-flex;
    align-items: center;
    padding: 0.5rem 1rem;
    border-radius: 0.375rem;
    font-weight: 500;
    font-size: 0.875rem;
  }
  
  .admin-status-online {
    background-color: rgba(34, 197, 94, 0.2);
    color: rgb(74, 222, 128);
  }
  
  .admin-status-offline {
    background-color: rgba(239, 68, 68, 0.2);
    color: rgb(248, 113, 113);
  }
  
  .admin-status-indicator-dot {
    width: 0.5rem;
    height: 0.5rem;
    border-radius: 9999px;
    margin-right: 0.5rem;
  }
  
  .admin-status-online .admin-status-indicator-dot {
    background-color: rgb(34, 197, 94);
  }
  
  .admin-status-offline .admin-status-indicator-dot {
    background-color: rgb(239, 68, 68);
  }
  
  /* Scroll Bar Styles */
  .easy-adminpanel ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  
  .easy-adminpanel ::-webkit-scrollbar-track {
    background: var(--admin-dark-blue-800);
  }
  
  .easy-adminpanel ::-webkit-scrollbar-thumb {
    background: var(--admin-dark-blue-500);
    border-radius: 4px;
  }
  
  .easy-adminpanel ::-webkit-scrollbar-thumb:hover {
    background: var(--admin-blue-500);
  }
  
  /* Animations */
  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
  
  .animate-fadeIn {
    animation: fadeIn 0.5s ease-in-out;
  }
  
  /* AdminPanel Component Styles */
  .easy-adminpanel {
    min-height: 100vh;
    background-color: var(--admin-dark-blue-900);
    color: white;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
      Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    display: flex;
  }
  
  .easy-adminpanel-header {
    border-bottom: 1px solid var(--admin-dark-blue-700);
    background-color: var(--admin-dark-blue-800);
    padding: 1.25rem 0;
  }
  
  .easy-adminpanel-card {
    background-color: var(--admin-dark-blue-800);
    border-radius: 0.5rem;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    transition: transform 0.2s, box-shadow 0.2s;
  }
  
  .easy-adminpanel-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  }
  
  .easy-adminpanel-card-title {
    font-size: 1.125rem;
    font-weight: 600;
    color: white;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
  }
  
  .easy-adminpanel-card-title svg {
    margin-right: 0.5rem;
    color: var(--admin-blue-400);
  }
  
  .easy-adminpanel-card-content {
    margin-bottom: 1rem;
  }
  
  .easy-adminpanel-card-footer {
    display: flex;
    justify-content: flex-end;
    padding-top: 1rem;
    border-top: 1px solid var(--admin-dark-blue-700);
  }
  
  .easy-adminpanel-button {
    display: inline-flex;
    align-items: center;
    padding: 0.5rem 1rem;
    border-radius: 0.375rem;
    font-weight: 500;
    margin-right: 0.5rem;
    cursor: pointer;
  }
  
  .easy-adminpanel-button svg {
    margin-right: 0.5rem;
  }
  
  .easy-adminpanel-button-primary {
    background-color: var(--admin-blue-500);
    color: white;
  }
  
  .easy-adminpanel-button-primary:hover {
    background-color: var(--admin-blue-400);
  }
  
  .easy-adminpanel-button-secondary {
    background-color: var(--admin-dark-blue-700);
    color: white;
  }
  
  .easy-adminpanel-button-secondary:hover {
    background-color: var(--admin-dark-blue-600);
  }
  
  .easy-adminpanel-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: white;
    margin-bottom: 1rem;
  }
  
  .easy-adminpanel-subtitle {
    font-size: 1.25rem;
    font-weight: 600;
    margin-bottom: 1rem;
  }
  
  .easy-adminpanel-content {
    flex: 1;
    padding: 1.5rem;
  }
  
  .easy-adminpanel-sidebar {
    width: 250px;
    background-color: var(--admin-dark-blue-800);
    min-height: 100vh;
    border-right: 1px solid var(--admin-dark-blue-700);
    padding: 1.5rem 0;
  }
  
  .easy-adminpanel-sidebar-header {
    padding: 0 1.5rem 1.5rem 1.5rem;
    border-bottom: 1px solid var(--admin-dark-blue-700);
    margin-bottom: 1.5rem;
  }
  
  .easy-adminpanel-sidebar-logo {
    display: flex;
    align-items: center;
    font-size: 1.25rem;
    font-weight: 700;
    color: white;
  }
  
  .easy-adminpanel-sidebar-logo svg {
    margin-right: 0.75rem;
    color: var(--admin-blue-400);
  }
  
  .easy-adminpanel-sidebar-nav {
    padding: 0 1rem;
  }
  
  .easy-adminpanel-sidebar-nav-item {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    color: var(--admin-gray-400);
    border-radius: 0.375rem;
    transition: all 0.2s;
    margin-bottom: 0.5rem;
    cursor: pointer;
  }
  
  .easy-adminpanel-sidebar-nav-item:hover {
    color: white;
    background-color: var(--admin-dark-blue-700);
  }
  
  .easy-adminpanel-sidebar-nav-item.active {
    color: white;
    background-color: var(--admin-dark-blue-600);
  }
  
  .easy-adminpanel-sidebar-nav-item svg {
    margin-right: 0.75rem;
  }
  
  .easy-adminpanel-main {
    flex: 1;
    min-width: 0;
  }
  
  /* Grid System for Cards */
  .easy-adminpanel-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
  }
  
  @media (max-width: 768px) {
    .easy-adminpanel-sidebar {
      width: 0;
      overflow: hidden;
    }
    
    .easy-adminpanel-sidebar.open {
      width: 250px;
    }
    
    .easy-adminpanel-main {
      margin-left: 0;
    }
  }
  `;

  const style = document.createElement("style");
  style.id = "easy-adminpanel-styles";
  style.innerHTML = cssContent;
  document.head.appendChild(style);

  // Add font link element
  const fontLink = document.createElement("link");
  fontLink.rel = "stylesheet";
  fontLink.href =
    "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap";
  document.head.appendChild(fontLink);
};

// Icons for the admin panel
const DatabaseIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="w-5 h-5"
  >
    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
    <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path>
    <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
  </svg>
);

const TableIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="w-5 h-5"
  >
    <path d="M3 3h18v18H3zM3 9h18M9 21V9"></path>
  </svg>
);

const ListIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="w-5 h-5"
  >
    <line x1="8" y1="6" x2="21" y2="6"></line>
    <line x1="8" y1="12" x2="21" y2="12"></line>
    <line x1="8" y1="18" x2="21" y2="18"></line>
    <line x1="3" y1="6" x2="3.01" y2="6"></line>
    <line x1="3" y1="12" x2="3.01" y2="12"></line>
    <line x1="3" y1="18" x2="3.01" y2="18"></line>
  </svg>
);

const PlusIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="w-5 h-5"
  >
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

// Main AdminPanel component
interface AdminPanelProps {
  /**
   * Connection string
   */
  connectionString?: string;

  /**
   * Database type (if can't be detected automatically)
   */
  databaseType?: "postgresql" | "mysql" | "mssql";

  /**
   * Panel title
   */
  title?: string;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  connectionString,
  databaseType,
  title = "Easy-AdminPanel",
}) => {
  // Define state for tables list
  const [tables, setTables] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [sidebarOpen, setSidebarOpen] = React.useState(true);

  // Load tables when the page loads
  useEffect(() => {
    // Inject styles when the component mounts
    injectStylesheet();

    // Load tables
    loadTables();
  }, []);

  // Function to load tables
  const loadTables = () => {
    setLoading(true);
    fetch("/api/tables")
      .then((res) => res.json())
      .then((data) => {
        if (data.tables && Array.isArray(data.tables)) {
          setTables(data.tables);
        } else {
          setTables([]);
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error loading tables:", error);
        setTables([]);
        setLoading(false);
      });
  };

  // Action when Manage Tables button is clicked
  const handleManageTables = () => {
    // Make API request
    fetch("/api/all-tables")
      .then((response) => response.json())
      .then((data) => {
        if (data.tables) {
          // Get currently selected tables
          fetch("/api/tables")
            .then((res) => res.json())
            .then((currentData) => {
              // Create modal for managing tables
              const dialogContainer = document.createElement("div");
              dialogContainer.className =
                "fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50";
              document.body.appendChild(dialogContainer);

              // Create modal content
              const dialog = document.createElement("div");
              dialog.className =
                "bg-white rounded-xl p-6 w-96 max-w-full shadow-2xl";
              dialog.innerHTML = `
                <h2 class="text-xl font-semibold mb-4 text-slate-800">
                  Select Tables to Manage
                </h2>
                <p class="mb-4 text-slate-600">
                  Choose the tables to display in your admin panel.
                </p>
                <div class="max-h-60 overflow-y-auto mb-4 pr-2 space-y-2" id="table-list">
                </div>
                <div class="flex justify-end space-x-2 pt-2 border-t border-slate-200">
                  <button id="cancel-btn" class="px-4 py-2 text-slate-600 hover:text-slate-900 text-sm font-medium rounded-lg hover:bg-slate-100">
                    Cancel
                  </button>
                  <button id="save-btn" class="flex items-center gap-1 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 shadow-sm">
                    <span>Save</span>
                  </button>
                </div>
              `;
              dialogContainer.appendChild(dialog);

              // Create table list
              const tableList = dialog.querySelector("#table-list");
              if (tableList) {
                const selectedTables = currentData.tables || [];

                data.tables.forEach((tableName: string) => {
                  const isSelected = selectedTables.some(
                    (t: any) => t.name === tableName || t === tableName
                  );

                  const tableItem = document.createElement("div");
                  tableItem.className =
                    "flex items-center p-2 rounded hover:bg-slate-50 transition-colors";
                  tableItem.innerHTML = `
                    <div class="flex items-center h-5">
                      <input
                        type="checkbox"
                        id="table-${tableName}"
                        data-table="${tableName}"
                        class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        ${isSelected ? "checked" : ""}
                      />
                    </div>
                    <label
                      for="table-${tableName}"
                      class="ml-3 text-gray-800 text-sm font-medium select-none"
                    >
                      ${tableName}
                    </label>
                  `;
                  tableList.appendChild(tableItem);
                });
              }

              // Cancel button
              const cancelBtn = dialog.querySelector("#cancel-btn");
              if (cancelBtn) {
                cancelBtn.addEventListener("click", () => {
                  document.body.removeChild(dialogContainer);
                });
              }

              // Save button
              const saveBtn = dialog.querySelector("#save-btn");
              if (saveBtn) {
                saveBtn.addEventListener("click", () => {
                  // Collect selected tables
                  const checkboxes = dialog.querySelectorAll(
                    'input[type="checkbox"]'
                  );
                  const selectedTables = Array.from(checkboxes)
                    .filter((cb: any) => cb.checked)
                    .map((cb: any) => ({
                      name: cb.dataset.table,
                      displayName: cb.dataset.table,
                    }));

                  // Save tables
                  fetch("/api/save-tables", {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                    },
                    body: JSON.stringify({ tables: selectedTables }),
                  })
                    .then(() => {
                      document.body.removeChild(dialogContainer);
                      // Reload tables instead of refreshing page
                      loadTables();
                    })
                    .catch((error) => {
                      console.error("Error saving tables:", error);
                    });
                });
              }
            });
        }
      })
      .catch((error) => {
        console.error("Error fetching tables:", error);
      });
  };

  // List records for a table
  const handleListTable = (tableName: string) => {
    window.location.href = `/easy-adminpanel/records?table=${tableName}`;
  };

  // Add new record to table
  const handleAddRecord = (tableName: string) => {
    window.location.href = `/easy-adminpanel/add-record?table=${tableName}`;
  };

  // Toggle sidebar
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="easy-adminpanel w-full min-h-screen">
      {/* Sidebar */}
      {sidebarOpen && (
        <div className="easy-adminpanel-sidebar">
          <div className="easy-adminpanel-sidebar-header">
            <div className="easy-adminpanel-sidebar-logo">
              <DatabaseIcon />
              <span>{title}</span>
            </div>
          </div>
          <div className="easy-adminpanel-sidebar-nav">
            <div className="easy-adminpanel-sidebar-nav-item active">
              <TableIcon />
              <span>Database Tables</span>
            </div>
          </div>
        </div>
      )}

      <div className="easy-adminpanel-main">
        {/* Header */}
        <header className="easy-adminpanel-header">
          <div className="admin-container">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <button
                  onClick={toggleSidebar}
                  className="mr-4 p-2 rounded hover:bg-admin-dark-blue-700 transition-colors"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="w-6 h-6"
                  >
                    <line x1="3" y1="12" x2="21" y2="12"></line>
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <line x1="3" y1="18" x2="21" y2="18"></line>
                  </svg>
                </button>
                <h1 className="easy-adminpanel-title">{title}</h1>
              </div>

              {/* Database status indicator */}
              <div className="admin-status-indicator admin-status-online">
                <span className="admin-status-indicator-dot"></span>
                <span>Connected</span>
              </div>
            </div>
          </div>
        </header>

        <div className="admin-container py-6">
          <div className="mb-6 flex justify-between items-center">
            <h2 className="easy-adminpanel-subtitle">Database Tables</h2>
            <button
              className="easy-adminpanel-button easy-adminpanel-button-primary"
              onClick={handleManageTables}
            >
              <TableIcon />
              Manage Tables
            </button>
          </div>

          {loading ? (
            <div className="easy-adminpanel-card p-8 flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-admin-blue-500"></div>
            </div>
          ) : tables.length === 0 ? (
            <div className="easy-adminpanel-card">
              <p className="text-admin-gray-400 mb-4">
                No tables have been selected yet. Use the "Manage Tables" button
                to select tables for data management.
              </p>
            </div>
          ) : (
            <div className="easy-adminpanel-grid">
              {tables.map((table: any) => (
                <div key={table.name} className="easy-adminpanel-card">
                  <h3 className="easy-adminpanel-card-title">
                    <TableIcon />
                    {table.displayName || table.name}
                  </h3>
                  <p className="text-admin-gray-400 text-sm mb-4">
                    {table.name}
                  </p>
                  <div className="flex space-x-2 mt-4">
                    <button
                      className="flex-1 easy-adminpanel-button easy-adminpanel-button-primary"
                      onClick={() => handleListTable(table.name)}
                    >
                      <ListIcon />
                      List
                    </button>
                    <button
                      className="flex-1 easy-adminpanel-button bg-green-600 hover:bg-green-500 text-white"
                      onClick={() => handleAddRecord(table.name)}
                    >
                      <PlusIcon />
                      Add
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Default export
export default AdminPanel;
